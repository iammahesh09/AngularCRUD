import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './Components/home/home.component';
import { AdminComponent } from './Components/admin/admin.component';
import { PageNotFoundComponent } from './page-not-found';
import { ProductsComponent } from './Components/products/products.component';
import { ProductsListComponent } from './Components/Products/products-list/products-list.component';
import { ProductDetailsComponent } from './Components/Products/product-details/product-details.component';
import { AddUserComponent } from './Components/CRUD/add-user/add-user.component';
import { EditUserComponent } from './Components/CRUD/edit-user/edit-user.component';
import { ListUserComponent } from './Components/CRUD/list-user/list-user.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AdminComponent,
    PageNotFoundComponent,
    ProductsComponent,
    ProductsListComponent,
    ProductDetailsComponent,
    AddUserComponent,
    EditUserComponent,
    ListUserComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
