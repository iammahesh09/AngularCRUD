import { Component } from '@angular/core';

@Component({
    selector: 'app-pagenotfound',
    template: `
        <h1 class="text-center text-danger">{{title}}</h1>
    `
})
export class PageNotFoundComponent {
    title = 'Page Not Found';
}
