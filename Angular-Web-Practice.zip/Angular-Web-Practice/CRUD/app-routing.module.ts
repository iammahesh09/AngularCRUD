import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './Components/home/home.component';
import { AdminComponent } from './Components/admin/admin.component';
import { PageNotFoundComponent } from './page-not-found';
import { ProductsComponent } from './Components/products/products.component';
import { AddUserComponent } from './Components/CRUD/add-user/add-user.component';
import { ListUserComponent } from './Components/CRUD/list-user/list-user.component';
import { EditUserComponent } from './Components/CRUD/edit-user/edit-user.component';

const _routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'add-user', component: AddUserComponent },
  { path: 'list-user', component: ListUserComponent },
  { path: 'edit-user', component: EditUserComponent },  
  { path: 'products', component: ProductsComponent },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(_routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
