import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  @Input('ParentProductDetails') item;
  @Output() showProducts= new EventEmitter();;

  constructor() { }

  GoToProducts(){
    this.showProducts.emit(null);
  }

  ngOnInit() {
  }

}
