import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../../Services/product.service';

@Component({
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css']
})
export class ProductsListComponent implements OnInit {
  productsData;
  item;
  
  exampleModalLong
  imgPth='https://raw.githubusercontent.com/SAP/openui5/master/src/sap.ui.demokit/test/sap/ui/demokit/explored/img';
  constructor(private _productService: ProductService) { }

  getProductDetails(product){
    this.item = product;
  }

  ngOnInit() {
    this._productService.getProducts().subscribe(
      res => {
        // console.log(res);
        this.productsData = res;
      },
      error => { console.log(error) }
    );
  }

  

}
