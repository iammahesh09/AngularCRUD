import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private productUrl: string = "https://raw.githubusercontent.com/SAP/openui5/master/src/sap.ui.demokit/test/sap/ui/demokit/explored/products.json"
  constructor(private _http: HttpClient) { }

  getProducts() {
    return this._http.get(this.productUrl).pipe(
      map(data => data['ProductCollection'])
    );
  }


}
