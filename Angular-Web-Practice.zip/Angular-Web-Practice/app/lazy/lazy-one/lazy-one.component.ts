import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lazy-one',
  templateUrl: './lazy-one.component.html',
  styleUrls: ['./lazy-one.component.css']
})
export class LazyOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
