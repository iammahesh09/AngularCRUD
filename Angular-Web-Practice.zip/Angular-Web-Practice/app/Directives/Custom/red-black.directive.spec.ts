import { RedBlackDirective } from './red-black.directive';

describe('RedBlackDirective', () => {
  it('should create an instance', () => {
    const directive = new RedBlackDirective();
    expect(directive).toBeTruthy();
  });
});
